export const moTa = "Di tru 0.1.0 -> 1.0.0 (khong doi du lieu, khung mau).";

export function migrate(data) {
  return data;
}
