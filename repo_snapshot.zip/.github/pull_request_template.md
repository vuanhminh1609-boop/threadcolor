## Mục tiêu
- 

## Thay đổi chính
- 

## Ảnh hưởng / rủi ro
- 

## Checklist test
- [ ] Không lỗi console
- [ ] Dòng “Xong. Dữ liệu đã sẵn sàng.” còn xuất hiện
- [ ] “Tìm mã chỉ gần nhất” trả kết quả
- [ ] Login top-right hoạt động

## Ảnh/Screenshot (nếu UI)
- 
