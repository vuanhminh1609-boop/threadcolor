# 01_NOW — Tuần này chúng ta đang làm gì

updated_at: 2025-12-31
owner: Chủ tịch / Thư ký tổng

## Top 3 ưu tiên (tuần này)
1.
2.
3.

## Đang làm (In progress)
-

## Tiếp theo (7 ngày)
-

## Anti-goals (tuần này KHÔNG làm)
-

## Rủi ro chính (tối đa 3)
-
