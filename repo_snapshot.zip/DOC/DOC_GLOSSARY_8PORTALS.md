# Tá»« Ä‘iá»ƒn thuáº­t ngá»¯ 8Portals (Viá»‡t hoÃ¡ 100%)

> Má»¥c tiÃªu: thá»‘ng nháº¥t ngÃ´n ngá»¯ chung trong repo 8Portals Ä‘á»ƒ trao Ä‘á»•i nhanh â€“ rÃµ â€“ â€œsang & sáº¡châ€.
>
> **Quy Æ°á»›c báº¥t biáº¿n (khÃ´ng Ä‘á»•i tÃªn):**
> 1) **DSG- DigitalSpaceGroup** â€” *Táº­p Ä‘oÃ n phÃ¡t triá»ƒn ká»¹ thuáº­t cÃ´ng nghá»‡ vÃ  khÃ´ng gian sá»‘ (CÃ´ng ty máº¹)*  
> 2) **SpaceColors - 8Portals** â€” *CÃ´ng ty con*

---

## 1) Thuáº­t ngá»¯ tá»• chá»©c & váº­n hÃ nh

| Thuáº­t ngá»¯ | Viá»‡t hoÃ¡ dÃ¹ng trong repo | Äá»‹nh nghÄ©a ngáº¯n |
|---|---|---|
| CEO | Tá»•ng giÃ¡m Ä‘á»‘c Ä‘iá»u hÃ nh | NgÆ°á»i chá»‘t phÆ°Æ¡ng Ã¡n tá»‘i Æ°u, ra quyáº¿t Ä‘á»‹nh Æ°u tiÃªn, chá»‹u trÃ¡ch nhiá»‡m káº¿t quáº£. |
| ThÆ° kÃ½ tá»•ng | ChÃ¡nh vÄƒn phÃ²ng Ä‘iá»u hÃ nh | NgÆ°á»i tá»•ng há»£p â€“ phÃ¢n loáº¡i â€“ nháº¯c nhá»‹p, táº¡o â€œbrief 1 trangâ€ + lá»‡nh Ä‘á» xuáº¥t cho Chá»§ tá»‹ch. |
| Thiáº¿t láº­p CÆ¡ cáº¥u Váº­n hÃ nh | Thiáº¿t láº­p CÆ¡ cáº¥u Váº­n hÃ nh | XÃ¡c Ä‘á»‹nh vai trÃ²â€“trÃ¡ch nhiá»‡mâ€“quyá»n háº¡nâ€“Ä‘áº§u raâ€“nhá»‹p Ä‘iá»u hÃ nh Ä‘á»ƒ tá»• chá»©c cháº¡y nhanh vÃ  khÃ´ng loáº¡n. |
| Nhá»‹p Ä‘iá»u hÃ nh | Nhá»‹p Ä‘iá»u hÃ nh | Lá»‹ch láº·p: háº±ng ngÃ y/tuáº§n/thÃ¡ng (brief, cáº­p nháº­t Æ°u tiÃªn, review rá»§i ro). |
| Sá»• quyáº¿t Ä‘á»‹nh | Nháº­t kÃ½ quyáº¿t Ä‘á»‹nh | Báº£ng ghi: ngÃ y, quyáº¿t Ä‘á»‹nh, lÃ½ do, rá»§i ro, tiÃªu chÃ­ quay Ä‘áº§u. |
| Sá»• rá»§i ro | Danh má»¥c rá»§i ro | Báº£ng rá»§i ro: xÃ¡c suáº¥t/tÃ¡c Ä‘á»™ng, chá»§ sá»Ÿ há»¯u, káº¿ hoáº¡ch giáº£m rá»§i ro. |
| HÃ ng Ä‘á»£i hÃ nh Ä‘á»™ng | Danh sÃ¡ch hÃ nh Ä‘á»™ng | Báº£ng viá»‡c cáº§n lÃ m: má»©c Ä‘á»™, owner, háº¡n, tráº¡ng thÃ¡i. |
| Chá»‰ sá»‘ báº¯c cáº§u | Chá»‰ sá»‘ dáº«n dáº¯t | Chá»‰ sá»‘ bÃ¡o trÆ°á»›c thÃ nh cÃ´ng (vÃ­ dá»¥: tá»‰ lá»‡ tÃ¬m tháº¥y Ä‘Ãºng mÃ u, thá»i gian tÃ¬m kiáº¿m). |
| Chá»‰ sá»‘ káº¿t quáº£ | Chá»‰ sá»‘ káº¿t quáº£ | Chá»‰ sá»‘ â€œÄ‘Ã­châ€ (vÃ­ dá»¥: sá»‘ ngÆ°á»i dÃ¹ng hoáº¡t Ä‘á»™ng, sá»‘ bá»™ dá»¯ liá»‡u Ä‘Æ°á»£c dÃ¹ng). |

---

## 2) Thuáº­t ngá»¯ sáº£n pháº©m (Portal/World)

| Thuáº­t ngá»¯ | Viá»‡t hoÃ¡ dÃ¹ng trong repo | Äá»‹nh nghÄ©a ngáº¯n |
|---|---|---|
| Portal | Cá»•ng | Äiá»ƒm vÃ o/Ä‘iá»u hÆ°á»›ng Ä‘áº¿n cÃ¡c â€œTháº¿ giá»›iâ€. |
| World | Tháº¿ giá»›i | Má»™t khÃ´ng gian chá»©c nÄƒng Ä‘á»™c láº­p trong 8Portals (vÃ­ dá»¥: MÃ u thÃªu, Kho chá»‰). |
| ThreadColor | Tháº¿ giá»›i MÃ u thÃªu (ThreadColor) | Tháº¿ giá»›i tra cá»©u/gá»£i Ã½ mÃ u chá»‰. |
| ThreadVault | Tháº¿ giá»›i Kho chá»‰ (ThreadVault) | Tháº¿ giá»›i quáº£n lÃ½/bá»™ sÆ°u táº­p chá»‰ vÃ  dá»¯ liá»‡u liÃªn quan. |
| Palette | Tháº¿ giá»›i Dáº£i mÃ u (Palette) | Tháº¿ giá»›i táº¡o/ghÃ©p/dÃ¹ng dáº£i mÃ u; cÃ³ thá»ƒ lÃ  â€œSáº¯p ra máº¯tâ€. |
| Topbar | Thanh trÃªn | Thanh Ä‘iá»u hÆ°á»›ng trÃªn cÃ¹ng; pháº£i giá»¯ **ÄÄƒng nháº­p** á»Ÿ gÃ³c pháº£i. |
| Slot Ä‘Äƒng nháº­p | Vá»‹ trÃ­ ÄÄƒng nháº­p | Khu vá»±c â€œneoâ€ hiá»ƒn thá»‹ Ä‘Äƒng nháº­p/Ä‘Äƒng xuáº¥t á»Ÿ top-right (khÃ´ng Ä‘Æ°á»£c Ä‘á»•i tuá»³ tiá»‡n). |
| Microcopy | Vi mÃ´ ngÃ´n tá»« | CÃ¢u chá»¯ ngáº¯n trong UI (nhÃ£n nÃºt, mÃ´ táº£) â€” pháº£i â€œÄ‘áº¯t vÃ  sáº¡châ€. |
| Tráº¡ng thÃ¡i rá»—ng | MÃ n hÃ¬nh rá»—ng | UI khi chÆ°a cÃ³ dá»¯ liá»‡u (pháº£i sang, khÃ´ng xin lá»—i). |
| Tráº¡ng thÃ¡i lá»—i | MÃ n hÃ¬nh lá»—i | UI khi cÃ³ lá»—i (gá»n, rÃµ, khÃ´ng hoáº£ng). |

---

## 3) Thuáº­t ngá»¯ dá»¯ liá»‡u & cháº¥t lÆ°á»£ng dá»¯ liá»‡u

| Thuáº­t ngá»¯ | Viá»‡t hoÃ¡ dÃ¹ng trong repo | Äá»‹nh nghÄ©a ngáº¯n |
|---|---|---|
| Source of truth | Nguá»“n dá»¯ liá»‡u gá»‘c | Nguá»“n chÃ­nh thá»©c, má»i thá»© khÃ¡c sinh ra tá»« Ä‘Ã¢y (vÃ­ dá»¥: `threads.json`). |
| Ngu&#7891;n s&#7921; th&#7853;t (single source of truth) | Ngu&#7891;n s&#7921; th&#7853;t (single source of truth) | Ngu&#7891;n d&#7919; li&#7879;u th&#7889;ng nh&#7845;t &#273;&#7875; tr&#225;nh l&#7879;ch s&#7889; (ngu&#7891;n d&#7919; li&#7879;u th&#7889;ng nh&#7845;t &#273;&#7875; tr&#225;nh l&#7879;ch s&#7889;). |
| M&#225;y tr&#7841;ng th&#225;i (state machine) | M&#225;y tr&#7841;ng th&#225;i (state machine) | Quy t&#7855;c chuy&#7875;n &#273;&#7893;i tr&#7841;ng th&#225;i loading/ok/warning/error (quy t&#7855;c chuy&#7875;n &#273;&#7893;i tr&#7841;ng th&#225;i loading/ok/warning/error). |
| Data contract | Há»£p Ä‘á»“ng dá»¯ liá»‡u | Quy Æ°á»›c: file nÃ o lÃ  gá»‘c, file nÃ o lÃ  sinh ra, schema, phiÃªn báº£n, cÃ¡ch cáº­p nháº­t. |
| JSON Schema | JSON Schema | Chuan mo ta cau truc JSON de kiem tra hop le (chuan mo ta cau truc JSON de kiem tra hop le). |
| SemVer | SemVer | Chuan danh phien ban MAJOR.MINOR.PATCH (chuan danh phien ban MAJOR.MINOR.PATCH). |
| Manifest hop dong | Manifest hop dong | Tep ke khai: dataset nao dung schema nao + phien ban + checksum (tep ke khai: dataset nao dung schema nao + phien ban + checksum). |
| Danh m&#7909;c t&#7879;p (manifest) | Danh m&#7909;c t&#7879;p (manifest) | Danh s&#225;ch li&#7879;t k&#234; t&#7879;p trong repo/snapshot &#273;&#7875; ki&#7875;m tra v&#224; &#273;&#7889;i chi&#7871;u. |
| JSONL | JSON Lines | Dinh dang JSON Lines: moi dong la 1 JSON, phu hop log/audit (dinh dang JSON Lines: moi dong la 1 JSON, phu hop log/audit). |
| Checksum | Checksum | Chuoi kiem chung toan ven du lieu (chuoi kiem chung toan ven du lieu). |
| SHA-256 | SHA-256 | Ham bam tao dau van tay noi dung (ham bam tao dau van tay noi dung). |
| Ajv | Ajv | Thu vien Node.js de kiem tra JSON Schema (thu vien Node.js de kiem tra JSON Schema). |
| CI gate | CI gate | Cong chan trong CI de ngan loi vao main (cong chan trong CI de ngan loi vao main). |
| additionalProperties | additionalProperties | Tuy chon cua JSON Schema cho phep field phat sinh (tuy chon cua JSON Schema cho phep field phat sinh). |
| authResolved | authResolved | Trang thai da xac dinh dang nhap hay chua (trang thai da xac dinh dang nhap hay chua). |
| Migration | Migration | Di tru du lieu khi doi schema (di tru du lieu khi doi schema). |
| Dry run | Dry run | Chay thu khong ghi du lieu (chay thu khong ghi du lieu). |
| Reproducible build | Reproducible build | Build tai lap nho lockfile (build tai lap nho lockfile). |
| Lockfile | Lockfile | Tep khoa phien ban phu thuoc, vi du package-lock.json (tep khoa phien ban phu thuoc, vi du package-lock.json). |
| Generated artifact | Tá»‡p sinh ra | File do cÃ´ng cá»¥ táº¡o (vÃ­ dá»¥: `threads.cleaned.json`) â€” thÆ°á»ng khÃ´ng commit. |
| Raw sources | Dá»¯ liá»‡u thÃ´ | Nguá»“n thÃ´ Ä‘áº§u vÃ o (vÃ­ dá»¥: `.tch`) dÃ¹ng Ä‘á»ƒ tÃ¡i táº¡o dá»¯ liá»‡u. |
| Validate | Kiá»ƒm tra há»£p lá»‡ | Kiá»ƒm tra cáº¥u trÃºc/logic dá»¯ liá»‡u Ä‘á»ƒ phÃ¡t hiá»‡n lá»—i sá»›m. |
| Normalize | Chuáº©n hoÃ¡ | Biáº¿n dá»¯ liá»‡u vá» dáº¡ng thá»‘ng nháº¥t (tÃªn, mÃ£, format). |
| Conflicts | MÃ¢u thuáº«n dá»¯ liá»‡u | CÃ¡c Ä‘iá»ƒm dá»¯ liá»‡u xung Ä‘á»™t cáº§n xá»­ lÃ½. |
| Versioning | ÄÃ¡nh phiÃªn báº£n | Gáº¯n phiÃªn báº£n dá»¯ liá»‡u Ä‘á»ƒ cache vÃ  truy váº¿t thay Ä‘á»•i. |

---

## 4) Thuáº­t ngá»¯ hiá»‡u nÄƒng & tráº£i nghiá»‡m

| Thuáº­t ngá»¯ | Viá»‡t hoÃ¡ dÃ¹ng trong repo | Äá»‹nh nghÄ©a ngáº¯n |
|---|---|---|
| Modal (h&#7897;p tho&#7841;i ph&#7911;) | Modal (h&#7897;p tho&#7841;i ph&#7911;) | H&#7897;p n&#7893;i ch&#7863;n n&#7873;n &#273;&#7875; hi&#7875;n th&#7883; th&#244;ng tin/t&#225;c v&#7909;. |
| Ng&#7919; c&#7843;nh ch&#7891;ng l&#7899;p (stacking context) | Ng&#7919; c&#7843;nh ch&#7891;ng l&#7899;p (stacking context) | C&#417; ch&#7871; quy&#7871;t &#273;&#7883;nh l&#7899;p tr&#234;n/d&#432;&#7899;i khi c&#243; blur/transform. |
| L&#7899;p ph&#7911; (overlay layer) | L&#7899;p ph&#7911; (overlay layer) | L&#7899;p n&#7893;i nh&#432; menu/popup ph&#7843;i n&#7857;m tr&#234;n n&#7897;i dung. |
| N&#226;ng l&#7899;p theo tr&#7841;ng th&#225;i (is-open z-index) | N&#226;ng l&#7899;p theo tr&#7841;ng th&#225;i (is-open z-index) | K&#7929; thu&#7853;t t&#259;ng z-index cho row &#273;ang m&#7903; menu. |
| M&#7853;t &#273;&#7897; UI | M&#7853;t &#273;&#7897; UI | &#272;&#7897; tho&#225;ng giao di&#7879;n (&#273;i&#7873;u ch&#7881;nh kho&#7843;ng c&#225;ch/padding/gap). |
| Menu th&#7843; xu&#7889;ng | Menu th&#7843; xu&#7889;ng | B&#7843;ng ch&#7885;n m&#7903; ra khi b&#7845;m n&#250;t (dropdown menu). |
| Logo mark (bi&#7875;u t&#432;&#7907;ng logo) | Logo mark (bi&#7875;u t&#432;&#7907;ng logo) | Bi&#7875;u t&#432;&#7907;ng r&#250;t g&#7885;n c&#7911;a logo, d&#249;ng &#273;&#7891;ng h&#224;nh v&#7899;i t&#234;n th&#432;&#417;ng hi&#7879;u. |
| H&#236;nh vector (SVG) | H&#236;nh vector (SVG) | &#7842;nh d&#7841;ng vector, ph&#243;ng to kh&#244;ng v&#7905; v&#224; nh&#7865; cho UI. |
| &#7842;nh &#273;a &#273;&#7897; ph&#226;n gi&#7843;i (srcset) | &#7842;nh &#273;a &#273;&#7897; ph&#226;n gi&#7843;i (srcset) | Khai b&#225;o nhi&#7873;u m&#7913;c &#273;&#7897; ph&#226;n gi&#7843;i &#273;&#7875; tr&#236;nh duy&#7879;t t&#7921; ch&#7885;n. |
| Fallback (ph&#432;&#417;ng &#225;n d&#7921; ph&#242;ng) | Fallback (ph&#432;&#417;ng &#225;n d&#7921; ph&#242;ng) | Ph&#432;&#417;ng &#225;n d&#7921; ph&#242;ng khi t&#224;i nguy&#234;n ch&#237;nh kh&#244;ng d&#249;ng &#273;&#432;&#7907;c. |
| L&#432;u c&#7909;c b&#7897; | L&#432;u c&#7909;c b&#7897; | L&#432;u l&#7921;a ch&#7885;n tr&#234;n tr&#236;nh duy&#7879;t b&#7857;ng localStorage. |
| S&#7921; ki&#7879;n tu&#7923; bi&#7871;n | S&#7921; ki&#7879;n tu&#7923; bi&#7871;n | CustomEvent &#273;&#7875; &#273;&#7891;ng b&#7897; tr&#7841;ng th&#225;i gi&#7919;a c&#225;c kh&#7889;i UI. |
| Worker | Tiáº¿n trÃ¬nh phá»¥ | Cháº¡y tÃ¡c vá»¥ náº·ng (tÃ¬m kiáº¿m, láº­p chá»‰ má»¥c) ngoÃ i luá»“ng chÃ­nh Ä‘á»ƒ UI mÆ°á»£t. |
| Main thread | Luá»“ng chÃ­nh | Luá»“ng cháº¡y UI; cÃ ng Ã­t viá»‡c cÃ ng mÆ°á»£t. |
| Index | Láº­p chá»‰ má»¥c | Chuáº©n bá»‹ cáº¥u trÃºc tra cá»©u nhanh (theo mÃ£, hÃ£ng, mÃ u). |
| Cache | Bá»™ nhá»› Ä‘á»‡m | LÆ°u táº¡m káº¿t quáº£ Ä‘á»ƒ táº£i nhanh hÆ¡n. |
| Debounce | Trá»… cÃ³ chá»§ Ä‘Ã­ch | Chá» ngÆ°á»i dÃ¹ng dá»«ng gÃµ rá»“i má»›i tÃ¬m, trÃ¡nh giáº­t. |
| Virtual list | Danh sÃ¡ch áº£o | Chá»‰ render pháº§n Ä‘ang nhÃ¬n tháº¥y Ä‘á»ƒ khá»i lag. |
| Latency | Äá»™ trá»… | Thá»i gian chá» pháº£n há»“i. |

---

## 5) Thuáº­t ngá»¯ kiá»ƒm thá»­ & â€œgÃ¡c cá»•ng cháº¥t lÆ°á»£ngâ€

| Thuáº­t ngá»¯ | Viá»‡t hoÃ¡ dÃ¹ng trong repo | Äá»‹nh nghÄ©a ngáº¯n |
|---|---|---|
| Smoke test | Kiá»ƒm tra khÃ³i | Kiá»ƒm tra nhanh: trang cÃ³ má»Ÿ Ä‘Æ°á»£c, file cÃ³ táº£i Ä‘Æ°á»£c, khÃ´ng 404. |
| Checklist PASS/FAIL | Danh sÃ¡ch Ä‘áº¡t/khÃ´ng Ä‘áº¡t | Danh sÃ¡ch test ngáº¯n gá»n Ä‘á»ƒ xÃ¡c nháº­n thay Ä‘á»•i an toÃ n. |
| Gate | Cá»•ng cháº·n | Quy táº¯c báº¯t buá»™c pháº£i qua trÆ°á»›c khi merge (vÃ­ dá»¥: khÃ´ng cÃ³ BLOCK). |
| Repo Doctor | BÃ¡c sÄ© kho mÃ£ | CÃ´ng cá»¥ quÃ©t repo: lá»—i gÃ£y (BLOCK), cáº£nh bÃ¡o (WARN), thÃ´ng tin (INFO). |
| Health Score | Äiá»ƒm sá»©c khoáº» | Äiá»ƒm 0â€“100 pháº£n Ã¡nh tÃ¬nh tráº¡ng repo theo quy táº¯c Ä‘Ã£ thá»‘ng nháº¥t. |
| Trend 7 ngÃ y | Xu hÆ°á»›ng 7 ngÃ y | Chuá»—i Ä‘iá»ƒm/Ä‘áº¿m trong 7 ngÃ y gáº§n nháº¥t Ä‘á»ƒ xem tiáº¿n hay lÃ¹i. |
| BLOCK | Cháº·n kháº©n cáº¥p | Lá»—i má»©c P0: lÃ m gÃ£y cháº¡y/thiáº¿u file runtime/syntaxâ€¦ => khÃ´ng merge. |
| WARN | Cáº£nh bÃ¡o | Váº¥n Ä‘á» cáº§n dá»n/tá»‘i Æ°u nhÆ°ng chÆ°a lÃ m gÃ£y há»‡. |
| INFO | Ghi nháº­n | ThÃ´ng tin thá»‘ng kÃª, khÃ´ng pháº£i lá»—i. |
| Quarantine | CÃ¡ch ly 7 ngÃ y | Chuyá»ƒn file â€œnghi thá»«aâ€ vÃ o `_graveyard/` trÆ°á»›c khi xoÃ¡ háº³n. |
| Graveyard | NghÄ©a Ä‘á»‹a táº¡m | ThÆ° má»¥c `_graveyard/` chá»©a file cÃ¡ch ly. |

---

## 6) Thuáº­t ngá»¯ Git & quy trÃ¬nh lÃ m viá»‡c

| Thuáº­t ngá»¯ | Viá»‡t hoÃ¡ dÃ¹ng trong repo | Äá»‹nh nghÄ©a ngáº¯n |
|---|---|---|
| Repo | Kho mÃ£ | NÆ¡i chá»©a toÃ n bá»™ mÃ£ nguá»“n, dá»¯ liá»‡u, tÃ i liá»‡u. |
| Commit | Báº£n ghi thay Ä‘á»•i | Má»‘c thay Ä‘á»•i cÃ³ mÃ´ táº£ rÃµ rÃ ng. |
| Branch | NhÃ¡nh | NhÃ¡nh lÃ m viá»‡c tÃ¡ch khá»i chÃ­nh. |
| Pull request (PR) | YÃªu cáº§u há»£p nháº¥t | Gá»­i thay Ä‘á»•i Ä‘á»ƒ review vÃ  há»£p nháº¥t vÃ o nhÃ¡nh chÃ­nh. |
| Merge | Há»£p nháº¥t | Gá»™p thay Ä‘á»•i vÃ o nhÃ¡nh chÃ­nh. |
| CI | Tá»± Ä‘á»™ng kiá»ƒm tra | Há»‡ thá»‘ng cháº¡y kiá»ƒm tra khi PR/push/schedule. |
| Workflow | Quy trÃ¬nh tá»± Ä‘á»™ng | Táº­p lá»‡nh CI (vÃ­ dá»¥: GitHub Actions). |
| workflow_dispatch | KÃ­ch hoáº¡t thá»§ cÃ´ng | Cháº¡y workflow báº±ng tay tá»« giao diá»‡n. |
| schedule | Lá»‹ch cháº¡y | Workflow cháº¡y theo cron (háº±ng ngÃ y). |
| Artifact | GÃ³i Ä‘Ã­nh kÃ¨m CI | File bÃ¡o cÃ¡o lÆ°u trong CI Ä‘á»ƒ táº£i vá» (khÃ´ng nháº¥t thiáº¿t commit). |

---

## 7) Thuáº­t ngá»¯ háº¡ táº§ng & báº£o máº­t

| Thuáº­t ngá»¯ | Viá»‡t hoÃ¡ dÃ¹ng trong repo | Äá»‹nh nghÄ©a ngáº¯n |
|---|---|---|
| Firestore rules | Quy táº¯c Firestore | Quy táº¯c truy cáº­p dá»¯ liá»‡u: ai Ä‘Æ°á»£c Ä‘á»c/ghi gÃ¬. |
| Least privilege | Tá»‘i thiá»ƒu quyá»n | Má»—i ngÆ°á»i chá»‰ cÃ³ Ä‘Ãºng quyá»n cáº§n thiáº¿t. |
| Auth | XÃ¡c thá»±c | Äá»‹nh danh ngÆ°á»i dÃ¹ng (Ä‘Äƒng nháº­p/Ä‘Äƒng xuáº¥t). |
| Custom claims | Quyá»n Ä‘áº·c biá»‡t | â€œCá»â€ phÃ¢n quyá»n nÃ¢ng cao (admin/mod). |

---

## 8) Thuáº­t ngá»¯ ra quyáº¿t Ä‘á»‹nh kiá»ƒu â€œÃ´ng lá»›nâ€

| Thuáº­t ngá»¯ | Viá»‡t hoÃ¡ dÃ¹ng trong repo | Äá»‹nh nghÄ©a ngáº¯n |
|---|---|---|
| One-way door | Cá»­a má»™t chiá»u | Quyáº¿t Ä‘á»‹nh khÃ³ quay Ä‘áº§u (pháº£i cÃ¢n nháº¯c ká»¹). |
| Two-way door | Cá»­a hai chiá»u | Quyáº¿t Ä‘á»‹nh cÃ³ thá»ƒ thá»­ nhanh vÃ  quay láº¡i. |
| Trade-off | ÄÃ¡nh Ä‘á»•i | Chá»n A thÃ¬ máº¥t B; pháº£i ghi rÃµ. |
| North Star Metric | Chá»‰ sá»‘ Báº¯c cá»±c | Chá»‰ sá»‘ cá»‘t lÃµi dáº«n toÃ n bá»™ Ä‘á»™i. |
| KPI | Chá»‰ sá»‘ hiá»‡u suáº¥t | Chá»‰ sá»‘ Ä‘o tiáº¿n Ä‘á»™/káº¿t quáº£. |
| OKR | Má»¥c tiÃªu & káº¿t quáº£ then chá»‘t | Há»‡ má»¥c tiÃªu theo quÃ½/thÃ¡ng. |

---

## 9) Quy táº¯c Ä‘áº·t thuáº­t ngá»¯ má»›i (Ä‘á»ƒ Viá»‡t hoÃ¡ 100%)
1) Æ¯u tiÃªn tá»« **ngáº¯n â€“ dá»… hiá»ƒu â€“ sang** (vÃ­ dá»¥: â€œCá»•ngâ€, â€œTháº¿ giá»›iâ€, â€œCÃ¡ch ly 7 ngÃ yâ€).  
2) Náº¿u báº¯t buá»™c giá»¯ tÃªn riÃªng (vÃ­ dá»¥: ThreadColor) â†’ luÃ´n kÃ¨m **bÃ­ danh tiáº¿ng Viá»‡t**: â€œTháº¿ giá»›i MÃ u thÃªu (ThreadColor)â€.  
3) Thuáº­t ngá»¯ ká»¹ thuáº­t váº«n Viá»‡t hoÃ¡, nhÆ°ng cÃ³ thá»ƒ giá»¯ trong ngoáº·c náº¿u cáº§n Ä‘á»‘i chiáº¿u: â€œBá»™ nhá»› Ä‘á»‡m (cache)â€.  
4) Hai tÃªn **khÃ´ng Ä‘á»•i**: **DSG- DigitalSpaceGroup**, **SpaceColors - 8Portals**.

---

*File nÃ y lÃ  â€œnguá»“n ngÃ´n ngá»¯ gá»‘câ€. Má»i tÃ i liá»‡u/brief nÃªn bÃ¡m theo Ä‘á»ƒ thá»‘ng nháº¥t giá»ng Ä‘iá»‡u.*
---

## 9) Thuáº­t ngá»¯ Backend & GÃ³i quyáº¿t Ä‘á»‹nh (Báº£o máº­t)

| Thuáº­t ngá»¯ | Viáº¿t hoÃ¡ dáº¡ng trong repo | Äá»‹nh nghÄ©a ngáº¯n |
|---|---|---|
| Cloud Functions (HÃ m Ä‘Ã¡m mÃ¢y) | Cloud Functions | HÃ m server-side cháº¡y theo sá»± kiá»‡n/HTTP, xá»­ lÃ½ logic nháº¡y cáº£m. |
| Firebase Hosting | Firebase Hosting | Háº¡ táº§ng phá»¥c vá»¥ web tÄ©nh vÃ  rewrite Ä‘áº¿n Functions. |
| Cross-Origin-Opener-Policy (COOP) | Cross-Origin-Opener-Policy (COOP) | Chinh sach co lap cua so mo ra giua cac nguon (chinh sach co lap cua so mo ra giua cac nguon). |
| same-origin-allow-popups | same-origin-allow-popups | Che do COOP cho phep popup van hoat dong voi cua so mo no (che do COOP cho phep popup van hoat dong voi cua so mo no). |
| signInWithRedirect | signInWithRedirect | Dang nhap bang chuyen huong thay vi popup (dang nhap bang chuyen huong thay vi popup). |
| Express | Express | Bá»™ Ä‘á»‹nh tuyáº¿n HTTP nháº¹ Ä‘á»ƒ tá»• chá»©c API admin. |
| rewrite (Ãnh xáº¡ Ä‘Æ°á»ng dáº«n) | rewrite | Chuyá»ƒn hÆ°á»›ng `/admin/**` tá»« Hosting sang Functions. |
| RBAC (PhÃ¢n quyá»n theo vai trÃ²) | RBAC | CÆ¡ cháº¿ phÃ¢n quyá»n admin/khÃ´ng admin theo vai trÃ². |
| ID token (mÃ£ chá»©ng thá»±c) | ID token | Token xÃ¡c thá»±c ngÆ°á»i dÃ¹ng do Firebase Auth cáº¥p. |
| no-store (cáº¥m cache) | no-store | Header chá»‘ng lÆ°u Ä‘á»‡m cho response nháº¡y cáº£m. |
| Audit log (nháº­t kÃ½ truy váº¿t) | Audit log | Ghi láº¡i GENERATE/VIEW, ai lÃ m, lÃºc nÃ o. |
| Redaction (che dá»¯ liá»‡u nháº¡y cáº£m) | Redaction | Che thÃ´ng tin nháº¡y cáº£m trÆ°á»›c khi lÆ°u/hiá»ƒn thá»‹. |
| DecisionPack (GÃ³i quyáº¿t Ä‘á»‹nh) | DecisionPack | Báº£n ghi gÃ³i quyáº¿t Ä‘á»‹nh ná»™i bá»™ theo ngÃ y. |
| Snapshot (báº£n chá»¥p) | Snapshot | Báº£n chá»¥p tráº¡ng thÃ¡i Ä‘á»ƒ Ä‘á»‘i chiáº¿u/ra quyáº¿t Ä‘á»‹nh. |
| Idempotency (chá»‘ng cháº¡y láº·p) | Idempotency | Cháº¡y láº¡i khÃ´ng táº¡o trÃ¹ng, giá»¯ 1 ?latest?. |
---

## 10) Thu?t ng? tri?n khai Functions & Hosting

| Thu?t ng? | Vi?t ho? d?ng trong repo | ??nh ngh?a ng?n |
|---|---|---|
| functions.source | functions.source | Khai b?o th? m?c m? Functions ?? deploy ??ng 100%. |
| predeploy | predeploy | L?nh ch?y t? ??ng tr??c khi deploy (v? d? build TypeScript). |
| emulator | emulator | M?i tr??ng gi? l?p Functions/Hosting ?? test local. |
| Node LTS | Node LTS | Phi?n b?n Node ?n ??nh d?i h?n, khuy?n ngh? d?ng trong Functions. |
---

## 11) Thuáº­t ngá»¯ quáº£n trá»‹ & xÃ¡c thá»±c bá»• sung

| Thuáº­t ngá»¯ | Viáº¿t hoÃ¡ dáº¡ng trong repo | Äá»‹nh nghÄ©a ngáº¯n |
|---|---|---|
| Authorization Bearer token | Bearer token | Chuá»—i token Ä‘áº·t trong header `Authorization: Bearer <token>` Ä‘á»ƒ gá»i API quáº£n trá»‹. |
| Admin UI | Báº£ng Ä‘iá»u phá»‘i quáº£n trá»‹ | Giao diá»‡n ná»™i bá»™ cho admin xem gÃ³i quyáº¿t Ä‘á»‹nh vÃ  nháº­t kÃ½ truy váº¿t. |
| Audit logs | Nháº­t kÃ½ truy váº¿t | Danh sÃ¡ch sá»± kiá»‡n truy cáº­p/ghi nháº­n á»Ÿ API admin, phá»¥c vá»¥ kiá»ƒm tra báº£o máº­t. |
---

## 12) Thuáº­t ngá»¯ Git hygiene

| Thuáº­t ngá»¯ | Viáº¿t hoÃ¡ dáº¡ng trong repo | Äá»‹nh nghÄ©a ngáº¯n |
|---|---|---|
| K&#7927; lu&#7853;t s&#7841;ch kho m&#227; (repo hygiene) | K&#7927; lu&#7853;t s&#7841;ch kho m&#227; (repo hygiene) | Th&#243;i quen gi&#7919; repo g&#7885;n, kh&#244;ng r&#242; r&#7881; file nh&#7841;y c&#7843;m, tu&#226;n th&#7911; quy &#432;&#7899;c. |
| .gitignore | .gitignore | Danh sÃ¡ch file/thÆ° má»¥c bá»‹ Git bá» qua, khÃ´ng Ä‘Æ°a vÃ o commit. |
| node_modules | node_modules | ThÆ° má»¥c chá»©a thÆ° viá»‡n cÃ i Ä‘áº·t tá»« npm; khÃ´ng commit. |
| Tracked | Tracked | File Ä‘ang Ä‘Æ°á»£c Git theo dÃµi (Ä‘Ã£ add). |
| Untracked | Untracked | File chÆ°a Ä‘Æ°á»£c Git theo dÃµi. |
| Build artifact | Build artifact | Káº¿t quáº£ sinh ra khi build (vÃ­ dá»¥ `functions/lib/`), khÃ´ng commit. |
---

## 13) Thuáº­t ngá»¯ xuáº¥t repo & chia sáº»

| Thuáº­t ngá»¯ | Viáº¿t hoÃ¡ dáº¡ng trong repo | Äá»‹nh nghÄ©a ngáº¯n |
|---|---|---|
| Git bundle | Git bundle | GÃ³i Git cÃ³ lá»‹ch sá»­ Ä‘áº§y Ä‘á»§, dÃ¹ng Ä‘á»ƒ chia sáº» repo mÃ  khÃ´ng cáº§n remote. |
| Git archive | Git archive | GÃ³i snapshot khÃ´ng lá»‹ch sá»­ (zip/tar) Ä‘á»ƒ chia sáº» mÃ£ nguá»“n hiá»‡n táº¡i. |
| Submodule | Submodule | Repo con gáº¯n vÃ o repo cha; cáº§n táº£i riÃªng khi chia sáº». |
| Git LFS | Git LFS | CÆ¡ cháº¿ lÆ°u file lá»›n ngoÃ i Git; cáº§n pull riÃªng Ä‘á»ƒ Ä‘á»§ dá»¯ liá»‡u. |
---

## 14) Thuáº­t ngá»¯ PowerShell

| Thuáº­t ngá»¯ | Viáº¿t hoÃ¡ dáº¡ng trong repo | Äá»‹nh nghÄ©a ngáº¯n |
|---|---|---|
| ExecutionPolicy | ExecutionPolicy | ChÃ­nh sÃ¡ch cho phÃ©p cháº¡y script PowerShell trong phiÃªn hiá»‡n táº¡i. |
| Scope Process | Scope Process | Pháº¡m vi Ã¡p dá»¥ng cá»§a ExecutionPolicy chá»‰ trong phiÃªn PowerShell Ä‘ang cháº¡y. |
---

## 15) Thuáº­t ngá»¯ Ä‘o lÆ°á»ng & sá»± kiá»‡n

| Thuáº­t ngá»¯ | Viáº¿t hoÃ¡ dáº¡ng trong repo | Äá»‹nh nghÄ©a ngáº¯n |
|---|---|---|
| North Star Metric (NSM) | NSM | Chá»‰ sá»‘ Ä‘á»‹nh hÆ°á»›ng chÃ­nh, Ä‘o hiá»‡u quáº£ cá»‘t lÃµi cá»§a sáº£n pháº©m. |
| Leading indicator | Chá»‰ sá»‘ dáº«n dáº¯t | Chá»‰ sá»‘ sá»›m dá»± bÃ¡o xu hÆ°á»›ng cá»§a NSM. |
| TMTC-7 | TMTC-7 | Tá»· lá»‡ MÃ u ThÃªu Chuáº©n trong 7 ngÃ y. |
| TTGP | TTGP | Tá»· lá»‡ Tra cá»©u Gáº§n Ä‘Ãºng thÃ nh cÃ´ng. |
| TLC | TLC | Tá»· lá»‡ LÆ°u vÃ o Kho chá»‰. |
| TLK | TLK | Tá»· lá»‡ Lá»±a chá»n káº¿t quáº£. |
| Event map | Báº£n Ä‘á»“ sá»± kiá»‡n | Danh sÃ¡ch sá»± kiá»‡n tá»‘i thiá»ƒu + thuá»™c tÃ­nh Ä‘á»ƒ Ä‘o lÆ°á»ng. |
---

## 16) Thuáº­t ngá»¯ Emulator & triá»ƒn khai

| Thuáº­t ngá»¯ | Viáº¿t hoÃ¡ dáº¡ng trong repo | Äá»‹nh nghÄ©a ngáº¯n |
|---|---|---|
| Emulator (mÃ´ phá»ng dá»‹ch vá»¥ cháº¡y local) | Emulator | Bá»™ giáº£ láº­p dá»‹ch vá»¥ Firebase cháº¡y trÃªn mÃ¡y local Ä‘á»ƒ test nhanh. |
| Blaze plan (gÃ³i tráº£ phÃ­ pay-as-you-go) | Blaze plan | GÃ³i tráº£ phÃ­ theo má»©c dÃ¹ng, cáº§n Ä‘á»ƒ dÃ¹ng má»™t sá»‘ tÃ­nh nÄƒng nÃ¢ng cao. |
| Spark plan (gÃ³i miá»…n phÃ­) | Spark plan | GÃ³i miá»…n phÃ­ vá»›i giá»›i háº¡n tÃ i nguyÃªn cÆ¡ báº£n. |
| Rewrite (Ä‘iá»u hÆ°á»›ng route trÃªn hosting) | Rewrite | Cáº¥u hÃ¬nh chuyá»ƒn hÆ°á»›ng route tÄ©nh sang Functions/API. |
| Smoke test (kiá»ƒm thá»­ nhanh tuyáº¿n chÃ­nh) | Smoke test | Kiá»ƒm tra nhanh cÃ¡c luá»“ng chÃ­nh Ä‘á»ƒ phÃ¡t hiá»‡n lá»—i lá»›n. |


