# CEO COCKPIT — 8Portals

Tham chiếu nhanh:
- North Star: (TODO)
- Now: (TODO)
- Architecture: DOC/00_TOAN_CANH.md
- Runtime Contract: DOC/03_RUNTIME_CONTRACT.md

## Điều hành 1-click
- [REPO_SNAPSHOT — Cây thư mục & thống kê](REPO_SNAPSHOT.md)
- [ACTIONS — Hàng đợi hành động](ACTIONS.md)
- [RISKS — Sổ rủi ro](RISKS.md)
- [01_NOW — Tuần này đang làm gì](01_NOW.md)
- [DECISIONS — Sổ quyết định](DECISIONS.md)

<!-- OPS_SUMMARY_START -->
updated_at: 2026-01-01
Health: Score 97 | BLOCK 0 | WARN 1 | INFO 5
Top việc (AUTO):
- [AUTO-D5187625][P1] TODO/FIXME - Owner: Design GPT - Tổng 31 mục
Top rủi ro (AUTO):
- (không có)
<!-- OPS_SUMMARY_END -->

## Sức khoẻ Repo

<!-- HEALTH_START -->
Điểm hiện tại: **--**
- BLOCK: 0 | WARN: 0

Top lý do:
- (chưa có)

| Ngày | Score | BLOCK | WARN |
|---|---:|---:|---:|
| 2025-12-31 | 97 | 0 | 1 |
| 2026-01-01 | 97 | 0 | 1 |
<!-- HEALTH_END -->
