# CEO COCKPIT — 8Portals

Tham chiếu nhanh:
- North Star: (TODO)
- Now: (TODO)
- Architecture: DOC/00_TOAN_CANH.md
- Runtime Contract: DOC/03_RUNTIME_CONTRACT.md

## Điều hành 1-click
- [REPO_SNAPSHOT — Cây thư mục & thống kê](REPO_SNAPSHOT.md)
- [ACTIONS — Hàng đợi hành động](ACTIONS.md)
- [RISKS — Sổ rủi ro](RISKS.md)
- [01_NOW — Tuần này đang làm gì](01_NOW.md)
- [DECISIONS — Sổ quyết định](DECISIONS.md)

## North Star & 3 leading
- [NORTH_STAR — TMTC-7](NORTH_STAR.md)
- [EVENT_MAP — Sự kiện tối thiểu](EVENT_MAP.md)

<!-- OPS_SUMMARY_START -->
updated_at: 2026-01-04
Health: Score 91 | BLOCK 0 | WARN 3 | INFO 5
Top việc (AUTO):
- [AUTO-649BEB65][P1] Asset/CSS không được tham chiếu - Owner: Design GPT - Không có refs_in
- [AUTO-717CFE01][P1] File lớn - Owner: Design GPT - 2859 KB
- [AUTO-D5187625][P1] TODO/FIXME - Owner: Design GPT - Tổng 31 mục
Top rủi ro (AUTO):
- (không có)
<!-- OPS_SUMMARY_END -->

## Sức khoẻ Repo

<!-- HEALTH_START -->
Điểm hiện tại: **91**
- BLOCK: 0 | WARN: 3

Top lý do:
- WARN: File lớn (1)
- WARN: Asset/CSS không được tham chiếu (1)
- WARN: TODO/FIXME (1)

| Ngày | Score | BLOCK | WARN |
|---|---:|---:|---:|
| 2025-12-31 | 97 | 0 | 1 |
| 2026-01-01 | 97 | 0 | 1 |
| 2026-01-02 | 97 | 0 | 1 |
| 2026-01-04 | 91 | 0 | 3 |
<!-- HEALTH_END -->
