# DECISIONS — Sổ quyết định

| Ngày | Quyết định | Lý do | One-way / Two-way | Rủi ro | Tiêu chí rollback |
|---|---|---|---|---|---|
| YYYY-MM-DD |  |  |  |  |  |
