# RISKS — Sổ rủi ro

<!-- AUTO_START -->
updated_at: 2026-01-04
Top rủi ro (AUTO):
- (không có)
<!-- AUTO_END -->

## THỦ CÔNG

| ID | Rủi ro | Xác suất (1-5) | Tác động (1-5) | Mức | Chủ sở hữu | Kế hoạch giảm rủi ro | Hạn |
|---|---|---:|---:|---|---|---|---|
| R-001 |  |  |  |  |  |  |  |