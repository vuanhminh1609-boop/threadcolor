# ACTIONS — Hàng đợi hành động

<!-- AUTO_START -->
updated_at: 2026-01-01
Health: Score 97 | BLOCK 0 | WARN 1 | INFO 5

Top việc cần làm (AUTO):
1. [AUTO-D5187625][P1] TODO/FIXME - Owner: Design GPT - Tổng 31 mục
<!-- AUTO_END -->

## THỦ CÔNG

| ID | Việc | Mức | Owner | Hạn | Trạng thái | Ghi chú |
|---|---|---|---|---|---|---|
| A-001 |  | P0/P1/P2 |  | YYYY-MM-DD | Todo/In progress/Done |  |