# ACTIONS — Hàng đợi hành động

<!-- AUTO_START -->
updated_at: 2026-01-04
Health: Score 91 | BLOCK 0 | WARN 3 | INFO 5

Top việc cần làm (AUTO):
1. [AUTO-649BEB65][P1] Asset/CSS không được tham chiếu - Owner: Design GPT - Không có refs_in
2. [AUTO-717CFE01][P1] File lớn - Owner: Design GPT - 2859 KB
3. [AUTO-D5187625][P1] TODO/FIXME - Owner: Design GPT - Tổng 31 mục
<!-- AUTO_END -->

## THỦ CÔNG

| ID | Việc | Mức | Owner | Hạn | Trạng thái | Ghi chú |
|---|---|---|---|---|---|---|
| A-001 |  | P0/P1/P2 |  | YYYY-MM-DD | Todo/In progress/Done |  |