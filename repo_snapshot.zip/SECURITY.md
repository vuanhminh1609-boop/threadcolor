# Bảo mật

Nếu bạn phát hiện lỗ hổng bảo mật:
- Vui lòng dùng tính năng “Report a vulnerability” trên GitHub để gửi báo cáo riêng tư.
- Không báo lỗ hổng nghiêm trọng qua Issues public.

Phạm vi:
- Ứng dụng web ThreadColor và các World liên quan.

Thời gian phản hồi dự kiến:
- Phản hồi ban đầu trong 3–7 ngày làm việc.
