# Báo cáo sức khoẻ Repo

- Điểm sức khoẻ: **97**
- BLOCK: 0 | WARN: 1 | INFO: 5

## BLOCK
- Không có.

## WARN
- TODO/FIXME: Tổng 31 mục (-)

## Top 5 gợi ý tối ưu sạch & đắt
- Dọn asset/CSS không dùng sau 7 ngày quarantine.
- Giảm file lớn hoặc tách tải theo nhu cầu.
- Giảm TODO/FIXME trong runtime core.
- Giữ missing nội bộ ở mức 0.
- Giữ điểm sức khoẻ > 90.
